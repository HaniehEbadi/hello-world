import csv
from os import name, write
# For the average
from statistics import mean 
# For the problem of arranging data entry in dictionary
from collections import OrderedDict

def calculate_averages(input_file_name, output_file_name):
    with open(input_file_name) as input_file:
        reader = csv.reader(input_file)
        output = dict()
        for row in reader:
            name = row[0]
            scores = list()
            for score in row[1:]:
                scores.append(int(score))
            output[name] = float(mean(scores))
    with open(output_file_name, 'w', newline='') as output_file:
        writer = csv.writer(output_file)
        writer.writerows(output.items())
        output_file.close()



def calculate_sorted_averages(input_file_name, output_file_name):
    with open(input_file_name) as input_file:
        reader = csv.reader(input_file)
        output = dict()
        for row in reader:
            output[row[0]] = row[1] #row[0]=name , row[1]=mean(scores)
        output = OrderedDict(sorted(output.items()))
    with open(output_file_name, 'w', newline='') as output_file:
        writer = csv.writer(output_file)
        writer.writerows(output.items())
        output_file.close()


def calculate_three_best(input_file_name, output_file_name):
    with open(input_file_name) as input_file:
        reader = csv.reader(input_file)
        output1 = dict()
        output = list()
        i = list()
        M = list()
        for line in reader:
            output1[line[0]] = float(line[1]) #line[0]=name , line[1]=mean(scores)
        output1 = OrderedDict(sorted(output1.items(), key= lambda t:t[1]))
        for i in range(0,3):
            M.append(max(output1.values()))
            output.append(output1.popitem())
        i = [(x,y) for x, y in output if y  == max(M)]
        n = 0
        while n < 3 :
            i = [(x,y) for x, y in output if y  == max(M)]
            if len(i) > 1:
                i = sorted(i)
                for k in range(0,len(i)) :
                    output.remove(i[k])
                output.extend(i)
            else :
                M.remove(max(M))
            n += 1
    with open(output_file_name, 'w', newline='') as output_file:
        writer = csv.writer(output_file)
        writer.writerows(output)
        output_file.close()


def calculate_three_worst(input_file_name, output_file_name):
    with open(input_file_name) as input_file:
        reader = csv.reader(input_file)
        averagelistfloat = list()
        averagelist = dict()
        for line in reader:
            averagelistfloat.append(float(line[1]))
        averagelistfloat.sort()
        i = 0
        for item in averagelistfloat:
            averagelist[i] = [str(item)]
            i += 1
        while len(averagelist) > 3:
            averagelist.popitem()
    with open(output_file_name, 'w', newline='') as output_file:
        writer = csv.writer(output_file)
        writer.writerows(averagelist.values())
        output_file.close()





def calculate_average_of_averages(input_file_name, output_file_name):
    with open(input_file_name) as input_file:
        reader = csv.reader(input_file)
        averages = list()
        average = list()
        for row in reader:
            averages.append(float(row[1]))
        average.append(mean(averages))
    with open(output_file_name, 'w', newline='') as output_file:
        writer = csv.writer(output_file)
        writer.writerow(average)
        output_file.close()


calculate_averages('/Users/Hanie/Desktop/HANIEH/python/Project/inputfile.csv', '/Users/Hanie/Desktop/HANIEH/python/Project/outputfile.csv')
calculate_sorted_averages('/Users/Hanie/Desktop/HANIEH/python/Project/outputfile.csv', '/Users/Hanie/Desktop/HANIEH/python/Project/outputfile2.csv')
calculate_three_best('/Users/Hanie/Desktop/HANIEH/python/Project/outputfile2.csv','/Users/Hanie/Desktop/HANIEH/python/Project/outputfile3.csv')
calculate_three_worst('/Users/Hanie/Desktop/HANIEH/python/Project/outputfile2.csv','/Users/Hanie/Desktop/HANIEH/python/Project/outputfile4.csv')
calculate_average_of_averages('/Users/Hanie/Desktop/HANIEH/python/Project/outputfile.csv','/Users/Hanie/Desktop/HANIEH/python/Project/outputfile5.csv')