SELECT *
FROM dbo.fnGetCourseID(3)

SELECT *
FROM dbo.fnGetCourseID(5)

SELECT *
FROM dbo.fnGetCourseID(6)

SELECT *
FROM dbo.fnGetCourseID(8)

SELECT *
FROM dbo.fnGetCourseID(10)