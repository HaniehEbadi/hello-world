SELECT *
FROM dbo.fnGetCourseID2(5)

SELECT *
FROM dbo.fnGetCourseID2(3)

SELECT *
FROM dbo.fnGetCourseID2(6)

SELECT *
FROM dbo.fnGetCourseID2(8)

SELECT *
FROM dbo.fnGetCourseID2(9)

SELECT *
FROM dbo.fnGetCourseID2(10)