SELECT *
FROM dbo.vwMaleStudent